# Banana Pi M2 Zero — Buildroot project notes

## Goal
Build a bootable microSD image for Banana Pi M2 Zero with Buildroot under WSL2/Ubuntu.

Expected image: `output/images/sdcard.img` (last verified size: about 193 MiB, 2026-10-29).

## Project layout
```text
banana-pi-m2-zero/
├── buildroot/                  # Buildroot source tree
│   ├── configs/bananapi_m2_zero_defconfig
│   └── board/bananapi/bananapi-m2-zero/
│       ├── boot.cmd
│       ├── genimage.cfg
│       ├── linux-wifi.fragment
│       └── rootfs-overlay/
│           └── etc/
│               ├── wpa_supplicant/wpa_supplicant.conf
│               └── init.d/S40wifi
├── output/                     # generated output; do not hand-edit
└── build.sh
```

## Build
From the project root:
```bash
chmod +x build.sh
./build.sh
```
The script runs Buildroot's dependency check and build, then checks that `output/images/sdcard.img` exists. It does **not** flash an SD card.

For a clean rebuild:
```bash
./build.sh --clean
```
This deletes `output/` after asking for explicit confirmation, then rebuilds. It can take a long time.

Equivalent manual commands:
```bash
cd ~/projects/banana-pi-m2-zero/buildroot
make O=../output dependencies
make O=../output
```
To initialize a missing output configuration:
```bash
make O=../output bananapi_m2_zero_defconfig
```
The script preserves an existing `output/.config` rather than silently overwriting custom settings.

## Build configuration summary
- Linux kernel defconfig: `sunxi`
- Device tree: `allwinner/sun8i-h2-plus-bananapi-m2-zero`
- Bootloader output: `u-boot-sunxi-with-spl.bin`
- Root filesystem: ext4, label `rootfs`
- Boot partition: FAT32, 64 MiB
- Root filesystem partition: 128 MiB
- Image assembled by `support/scripts/genimage.sh` and `board/bananapi/bananapi-m2-zero/genimage.cfg`
- Wi-Fi intended to use Broadcom/Cypress SDIO firmware and `brcmfmac`
- `wpa_supplicant` and Dropbear SSH are enabled in the current configuration
- SSH public key is installed to `/root/.ssh/authorized_keys`

## Current boot arguments
`board/bananapi/bananapi-m2-zero/boot.cmd` should contain:
```text
setenv bootargs console=ttyS0,115200 earlyprintk root=LABEL=rootfs rootwait
```
Using `root=LABEL=rootfs` avoids hardcoding `mmcblk0p2` or `mmcblk1p2`. The generated root filesystem was checked with `blkid` and had label `rootfs`.

## Expected image contents
At the last successful image assembly:
- `sdcard.img` — ~193 MiB
- `boot.vfat` — 64 MiB
- `rootfs.ext2` — 128 MiB
- `rootfs.ext4` — symlink to `rootfs.ext2`
- `zImage`
- `sun8i-h2-plus-bananapi-m2-zero.dtb`
- `u-boot-sunxi-with-spl.bin`
- `boot.scr`

`fdisk -l output/images/sdcard.img` showed:
- partition 1: starts at sector 2048, 64 MiB, FAT32 LBA, bootable
- partition 2: starts at sector 133120, 128 MiB, Linux

## WSL download issues encountered
Some upstream downloads timed out from WSL. The following manual cache workaround was used or discussed:
- `wpa_supplicant-2.12.tar.gz`, SHA-256: `08e23937e16d0155e55cab2b51f51fbe10d80a1aa91c4e15442645059b737ef6`
- `swig-4.1.1.tar.gz`, expected SHA-256 from Buildroot's `package/swig/swig.hash`: `2af08aced8fcd65cdb5cc62426768914bedc735b1c250325203716f78e39ac9b`
- GCC archive hashes must be checked against the archive actually downloaded and a trusted checksum source. Never bypass Buildroot hash validation.
If manually downloading an archive in Windows, copy it into the appropriate Buildroot `dl/` cache subdirectory (confirm the expected subdirectory in the package `.mk` file), and verify its hash before rebuilding.

## Security
- Do not commit real Wi-Fi credentials from `rootfs-overlay/etc/wpa_supplicant/wpa_supplicant.conf`.
- Do not publish `output/.config` without checking it for secrets and deployment-specific values.
- Keep the SSH private key on the client computer. Only the public key belongs in `root/.ssh/authorized_keys`.
- Do not paste Wi-Fi passwords, root passwords, private keys, or unreviewed config files into chat.

## Making a new board project
This build setup is specific to Banana Pi M2 Zero. For a different board:
1. Create a separate project directory and use a clean Buildroot source checkout/archive.
2. Choose a defconfig supported by the target board or create one from the closest supported configuration.
3. Create board files: bootloader configuration, kernel config/fragment, DTS selection, `boot.cmd`, `genimage.cfg`, and rootfs overlay.
4. Update the Buildroot defconfig for the correct bootloader defconfig and output filename, kernel defconfig, device tree, root filesystem, and post-image script arguments.
5. Verify the target's boot ROM/bootloader requirements and root-device arguments.
6. Build, inspect with `fdisk -l`, and test on hardware.
7. Keep credentials and private keys out of version control.

Renaming this directory alone does not make the project compatible with a different board.
