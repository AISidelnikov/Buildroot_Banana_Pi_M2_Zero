#!/usr/bin/env bash
set -Eeuo pipefail

# Build the existing Banana Pi M2 Zero Buildroot project.
# This script DOES NOT write to a microSD card.
# Usage: ./build.sh [--clean]

PROJECT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BR_DIR="$PROJECT_DIR/buildroot"
OUT_DIR="$PROJECT_DIR/output"
DEFCONFIG="bananapi_m2_zero_defconfig"
IMAGE="$OUT_DIR/images/sdcard.img"

die() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
log() { printf '\n==> %s\n' "$*"; }

[[ -f "$BR_DIR/Makefile" ]] || die "Buildroot Makefile not found: $BR_DIR/Makefile"
[[ -f "$BR_DIR/configs/$DEFCONFIG" ]] || die "Defconfig not found: $BR_DIR/configs/$DEFCONFIG"

# Avoid WSL's imported Windows PATH entries causing command/path issues.
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

if [[ "${1:-}" == "--clean" ]]; then
    [[ "$#" -eq 1 ]] || die "Usage: $0 [--clean]"
    if [[ -e "$OUT_DIR" ]]; then
        printf 'This removes generated build output: %s\n' "$OUT_DIR"
        read -r -p 'Type DELETE to continue: ' answer
        [[ "$answer" == "DELETE" ]] || die "Cancelled."
        rm -rf -- "$OUT_DIR"
    fi
elif [[ "$#" -ne 0 ]]; then
    die "Usage: $0 [--clean]"
fi

log "Check Buildroot dependencies"
make -C "$BR_DIR" O="$OUT_DIR" dependencies

if [[ ! -f "$OUT_DIR/.config" ]]; then
    log "Initialize configuration: $DEFCONFIG"
    make -C "$BR_DIR" O="$OUT_DIR" "$DEFCONFIG"
else
    log "Preserving existing output/.config"
    printf 'To reset configuration explicitly, run:\n  make -C "%s" O="%s" %s\n' "$BR_DIR" "$OUT_DIR" "$DEFCONFIG"
fi

log "Build firmware image"
make -C "$BR_DIR" O="$OUT_DIR"

[[ -s "$IMAGE" ]] || die "Build completed but image is missing/empty: $IMAGE"

log "Image created"
ls -lh "$IMAGE"
printf '\nImage directory:\n'
ls -lh "$OUT_DIR/images"
printf '\nPartition table inspection:\n  fdisk -l "%s"\n' "$IMAGE"
printf '\nNo SD card was written.\n'
